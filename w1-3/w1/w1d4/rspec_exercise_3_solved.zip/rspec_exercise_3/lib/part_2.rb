def element_count(arr)
    hash = Hash.new(0)
    arr.each do |ele|
        hash[ele] += 1
    end
    hash
end

def char_replace!(str, hash)
    # new_arr = str.split("")
    # new_arr.map! {|ele| hash.has_key?(ele) ? hash[ele] : ele}
    # new_arr.join("")
    (0..str.length).each do |i|
        if hash.has_key?(str[i])
            str[i] = hash[str[i]]
        end
    end
    
    # str.each_char.with_index do |char, idx|
    #     if hash.has_key?(char)
    #         char = hash[char]
    #         str[idx] = char
    #     end
    # end
    str
end

# condition ? true : false

def product_inject(arr)
    arr.inject {|acc, ele| acc * ele}
end
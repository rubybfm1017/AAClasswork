def proper_factors(num)
    new_arr = []
    (1...num).each do |factor|
        new_arr << factor if num % factor == 0
    end
    new_arr
end

def aliquot_sum(num)
    proper_factors(num).sum
end

def perfect_number?(num)
    num == aliquot_sum(num) ? true : false
end

def ideal_numbers(num)
    new_arr = []
    i = 1
    while new_arr.length < num 
        if perfect_number?(i)
            new_arr << i
        end
        i += 1
    end
    new_arr
end
def palindrome?(str)
    str.each_char.with_index do |char, idx|
        if str[idx] != str[-idx-1]
            return false 
        end
    end
    true
end

def substrings(str)
    result = []
    (0...str.length).each do |i|# i = 0 
        (i...str.length).each do |j| # j=2
            result << str[i..j]  # "ju" p
        end
    end
    result
end

def palindrome_substrings(str)
    result = []
    subs = substrings(str)
    subs.each do |sub|
        if palindrome?(sub) && sub.length > 1
            result << sub
        end
    end
    result
end
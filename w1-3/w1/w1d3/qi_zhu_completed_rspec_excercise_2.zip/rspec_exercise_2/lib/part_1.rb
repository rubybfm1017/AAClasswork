def partition(arr, num)
    output = [[],[]]
    arr.each do |ele|
        if ele < num 
            output[0] << ele
        else 
            output[1] << ele
        end
    end
    output
end

def merge(hash1, hash2)
    output = {}
    hash1.each do |k1,v1|
        hash2.each do |k2, v2|
            if k1 == k2 
                output[k2] = v2
            else   
                output[k2] = v2
            end
        end
        if !hash2.include?(k1)
            output[k1] = v1
        end
    end
    output
end

def censor(str, arr)
    words = str.split
    output = words.map do |word|
        if arr.include?(word.downcase)
            remove_vowels(word)
        else
            word
        end
    end
    output.join(' ')
end

def remove_vowels(word)
    vowels = 'aeiouAEIOU'
    output = ''
    word.each_char do |char|
        if vowels.include?(char)
            output += '*'
        else
            output += char
        end
    end
    output
end

def power_of_two?(num)
   pow = 2
   counter = 1
    while counter < num
        counter = counter * pow
    end
    counter == num ? true : false
end

